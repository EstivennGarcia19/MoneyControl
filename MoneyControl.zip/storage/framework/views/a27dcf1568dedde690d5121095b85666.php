<?php $__env->startSection('btn-expenses-nav'); ?>

<li>
    <button form="this-form" ><i class='bx bx-plus'></i></button>
</li>



<?php $__env->stopSection(); ?><?php /**PATH C:\xampp\htdocs\MoneyControl\resources\views/Layouts/nav/btn-expenses-nav.blade.php ENDPATH**/ ?>