<?php $__env->startSection('principal-container'); ?>
    <section id="home-history">


        
        <article id="section-tittle-history">
            <div class="back" onclick="back()"><i class='bx bx-chevron-left'></i></div>
            <div class="tittle"><span>Ingresos registrados</span></div>
            <div class="invisible">
                <p>p</p>
            </div>
        </article>



        
        <section id="list-history">

            <p>Esos han sido tus ingresos</p>


            <?php if($incomes->isEmpty()): ?>
                <section class="there-nothing">
                    <span class="text-danger">Aun no tienes ingresos</span>
                    <img src="<?php echo e(asset('media/nothing4.png')); ?>" alt="">
                </section>
            <?php else: ?>
                <?php $__currentLoopData = $incomes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $copAmount = number_format($item->amount, 0, ',', ','); ?>
                    <div class="history">
                        <article class="info">

                            <div class="icon text-light">
                                <i class='bx bx-message-square-detail'></i>
                            </div>
                            <div class="date-state">
                                
                                <h3 class="text-light"><?php echo e(formatFullDate($item->date)); ?></h3>
                            </div>

                        </article>

                        <article class="amount income">
                            <span>$<?php echo e($copAmount); ?></span>
                        </article>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>



        </section>


    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.nav.nav-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Layouts.html', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MoneyControl\resources\views/History/incomesHistory.blade.php ENDPATH**/ ?>