<?php $__env->startSection('tittle-head'); ?>
    Add Day
<?php $__env->stopSection(); ?>

<?php
use Carbon\Carbon;
?>


<?php $__env->startSection('principal-container'); ?>
    <section id="home-history">


        
        <article id="section-tittle-history">
            <div class="back" onclick="back()"><i class='bx bx-chevron-left'></i></div>
            <div class="tittle"><span>Agregar compra</span></div>
            <div class="invisible">
                <p>p</p>
            </div>
        </article>



        
        <section id="list-history">

            <p>Si olvidaste anotar un gasto aqui puedes seleccionar el dia y anotarlo facilmente</p>

            <form id="forgotten-day" action="<?php echo e(route('history.addforgottenDay')); ?>" method="POST">
                
                <?php echo csrf_field(); ?>
                
                <input type="text" name="name" placeholder="Nombre" required>
                <input type="text" inputmode="numeric" name="price" class="price" placeholder="Precio" required>
                <input type="date" name="date" placeholder="Selecciona una fecha ->"  required>
                <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">

                <button>Agregar</button>

                
            </form>
        </section>


    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js/formatCOP.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('Layouts.nav.nav-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Layouts.html', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MoneyControl\resources\views/History/addDayForgottenHistory.blade.php ENDPATH**/ ?>