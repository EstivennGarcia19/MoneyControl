<?php $__env->startSection('principal-container'); ?>

<div id="welcome">

    <div id="hero">
        <img src="<?php echo e(asset('media/hero2.svg')); ?>" alt="">
    </div>

    <article class="information">
        <h2>Money Control</h2>
        <p>Para que tengas en cuenta en que tanto gastas la plata</p>
    </article>

    <article class="btn-container">
        <a href="<?php echo e(route('login.index_login')); ?>" class="active">Iniciar sesion</a>
        <a href="<?php echo e(route('login.index_register')); ?>">Registrarse</a>
    </article>

</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.html', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MoneyControl\resources\views/welcome.blade.php ENDPATH**/ ?>