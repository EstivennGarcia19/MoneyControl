<?php $__env->startSection('btn-chests-nav'); ?>

<li>
    <button type="button" data-bs-toggle="modal" data-bs-target="#staticBackdrop"><i class='bx bx-plus'></i></button>    
</li>

<?php $__env->stopSection(); ?><?php /**PATH C:\xampp\htdocs\MoneyControl\resources\views/Layouts/nav/btn-chests-nav.blade.php ENDPATH**/ ?>