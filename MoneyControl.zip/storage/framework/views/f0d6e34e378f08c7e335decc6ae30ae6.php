<?php $__env->startSection('tittle-head'); ?>
    Register
<?php $__env->stopSection(); ?>


<?php $__env->startSection('principal-container'); ?>
    <section id="register">
        


        <section id="section-tittle-login">
            <div class="back" onclick="back()"><i class='bx bx-chevron-left'></i></div>
        </section>
        <div class="tittle">
            <h2>Iniciar Sesion</h2>
        </div>

        <article class="form-container">

            <form id="register-form" action="<?php echo e(route('login.login')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                
                <?php if($errors->has('email')): ?>
                    <div class="alert alert-danger"><?php echo e($errors->first('email')); ?></div>
                <?php endif; ?>
                
                <?php if($errors->has('password')): ?>
                    <div class="alert alert-danger"><?php echo e($errors->first('password')); ?></div>
                <?php endif; ?>

                <input type="text" name="email" placeholder="Correo" required value="<?php echo e(old('email')); ?>">
                <input type="password" name="password" placeholder="Contraseña" required>
                <div class="rememberme">
                    <input type="checkbox" name="remember" id="remember">
                    <label for="remember" class="text-light ms-2">Recordar</label>
                </div>

                <button>Ingresar</button>

                <article class="redirect-lr">
                    <a href="<?php echo e(route('login.index_register')); ?>">¿Eres nuevo?</a>
                </article>

            </form>
        </article>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.html', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MoneyControl\resources\views/login-register/login.blade.php ENDPATH**/ ?>