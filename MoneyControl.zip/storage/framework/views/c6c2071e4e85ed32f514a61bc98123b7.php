<?php $__env->startSection('tittle-head'); ?> 
Chests
<?php $__env->stopSection(); ?>

<?php
// Se hace la llamada a esta api para formatear la fecha mas abajo en este archivo
use Carbon\Carbon;
Carbon::setLocale('es');

?>


<?php $__env->startSection('principal-container'); ?>
    <div id="chests">

        <section id="section-tittle-chest">
            <div class="back" onclick="back()"><i class='bx bx-chevron-left'></i></div>
            <div class="tittle"><span>Cofres</span></div>
            
            <div class="invisible">
                <p>XD</p>
            </div>

        </section>

        <article class="info-chests">
            
            <p>Crea cofres donde puedes guardar un monto especifico de dinero</p>
        </article>


        <section id="my-chests">

            <?php if($myChests->isEmpty()): ?>

                <section class="there-nothing">
                    <span class="text-danger">No has creado un cofre aún</span>
                    <img src="<?php echo e(asset('media/nothing3.png')); ?>" alt="">
                </section>
            <?php else: ?>
                <?php $__currentLoopData = $myChests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $copAmount = number_format($chest->amount, 0, ',', ','); ?>

                    <article class="chest" style="background-color:<?php echo e($chest->color); ?>">

                        <a href="<?php echo e(route('chest.show', $chest->id)); ?>">

                            <div class="circle-chest">
                                <img src="<?php echo e(asset('media/cofre-icon3.png')); ?>" alt="">
                            </div>
    
                            <div class="tittle-chest">
                                <span><?php echo e($chest->name); ?></span>
                            </div>
    
                            <div class="current-amount">
                                <span href="#">$<?php echo e($copAmount); ?></span>
                            </div>
    
                            <div class="date-created">
                                <span>Creado</span>
                                
                                <span><?php echo e(Carbon::parse($chest->date)->format('d M')); ?>

                                </span>
                            </div>
                        </a>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

        </section>
    </div>



    <!-- Modal -->
    <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
        aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header d-flex justify-content-between">
                    <h1 class="modal-title fs-5 text-light" id="addMoreAmountLabel">Nuevo cofre</h1>
                    <button type="button" class="btn text-light" data-bs-dismiss="modal"><i class='bx bx-x'></i></button>
                </div>
                <div class="modal-body">
                    <div class="my-content-modal">
                        <form id="form-chest" action="<?php echo e(route('chests.store')); ?>" method="POST">
                            
                            <?php echo csrf_field(); ?>
                            
                            <input type="text" name="name" placeholder="Elige un nombre"> <br>
                            <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                            <button type="submit" form="form-chest">Crear</button>
                        </form>

                    </div>

                </div>


            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.nav.btn-chests-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Layouts.nav.nav-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Layouts.html', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MoneyControl\resources\views/Chests/index_chests.blade.php ENDPATH**/ ?>