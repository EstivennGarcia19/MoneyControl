<?php 
    use Carbon\Carbon;
    $date_month = $date_tittle->first()->date
 ?>


<?php $__env->startSection('principal-container'); ?>
    <section id="home-history">


        
        <article id="section-tittle-history">
            <div class="back" onclick="back()"><i class='bx bx-chevron-left'></i></div>
            <div class="tittle"><span><?php echo e(formatMonthDate($date_month)); ?></span></div>
            <div class="invisible">
                <p>p</p>
            </div>
        </article>


        <section id="days-container">

            <?php $__currentLoopData = $collection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php 
                $day_number = Carbon::parse($item->date)->formatLocalized('%d')
             ?>            
            <div class="day">
                <a href="<?php echo e(route('history.detailDay', ['day'=>$item->date])); ?>">
                    <h2><?php echo e($day_number); ?></h2>
                    <span><?php echo e(formatCOP($item->total)); ?></span>    
                </a>
            </div>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
        </section>                
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.nav.nav-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Layouts.html', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MoneyControl\resources\views/History/daysHistory.blade.php ENDPATH**/ ?>