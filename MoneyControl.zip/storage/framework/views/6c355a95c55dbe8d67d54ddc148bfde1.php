<?php
    $date_day = $date_tittle->first()->date;

?>


<?php $__env->startSection('principal-container'); ?>
    <section id="home-history">      
        
        <article id="section-tittle-history">
            <div class="back" onclick="back()"><i class='bx bx-chevron-left'></i></div>
            <div class="tittle"><span><?php echo e(formatDate($date_day)); ?></span></div>

            <div class="invisible">
                <p>p</p>    
            </div>
        </article>

        <section id="days-container">

            <article class="info">
                <p>Hola, Este dia compraste esto:</p>
            </article>

            <ol>
                <?php $__currentLoopData = $detail_days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $copAmount = number_format($item->price, 0, ',', ','); ?>
                    <li>
                        <article class="things-purshased">
                            <p>x</p>
                            <span><?php echo e($item->name); ?></span>
                            <span>$<?php echo e(formatCOP($item->price)); ?></span>
                        </article>

                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ol>

        </section>

        <div id="forgotAdd" data-bs-toggle="modal" data-bs-target="#addMoreAmount">
            <i class='bx bx-question-mark bx-tada'></i>
        </div>

        <div class="modal fade" id="addMoreAmount" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
            aria-labelledby="addMoreAmountLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                <div class="modal-content">
                    <div class="modal-header d-flex justify-content-between">
                        <h1 class="modal-title fs-5" id="removeAmount">¿Que olvidaste?</h1>
                        <button type="button" class="btn text-light" data-bs-dismiss="modal"><i
                                class='bx bx-x'></i></button>
                    </div>
                    <div class="modal-body">
                        <div class="my-content-modal">

                            <form action="<?php echo e(route('history.store')); ?>" method="POST">
                                <?php echo method_field('PUT'); ?>
                                <?php echo csrf_field(); ?>

                                <article>
                                    <div>
                                        <label for="name"><i class='bx bx-calendar-edit'></i></label>
                                        <input type="text" placeholder="Nombre" id="input_add_amount" name="name"
                                            value="">
                                    </div>
                                    <div>
                                        <label for="price"><i class='bx bx-wallet'></i></label>
                                        
                                        <input type="text" placeholder="Cuanto" inputmode="numeric" class="price" id="input_add_amount" name="price">
                                    </div>
                                    <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                                    <input type="hidden" name="date" value="<?php echo e($date_day); ?>">
                                </article>

                                <button><i class='bx bx-plus'></i></button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js/formatCOP.js')); ?>"></script>

    
<?php $__env->stopPush(); ?>


<?php echo $__env->make('Layouts.nav.nav-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Layouts.html', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MoneyControl\resources\views/History/detailDayHistory.blade.php ENDPATH**/ ?>