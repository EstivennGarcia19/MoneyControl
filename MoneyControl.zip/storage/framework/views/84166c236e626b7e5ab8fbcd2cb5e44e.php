<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('tittle-head'); ?></title>
    <?php echo $__env->yieldPushContent('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />

</head>

<body>   
    <?php echo $__env->yieldContent('principal-container'); ?>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="<?php echo e(asset('js/back.js')); ?>"></script>
    <script src="<?php echo e(asset('js/myFunctions.js')); ?>"></script>
    <script src="<?php echo e(asset('js/openOptions.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous">
    </script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
    <script>
        $(document).ready(function() {
            // Obtén la URL actual
            var currentUrl = window.location.href;

            // Itera sobre cada enlace dentro de la barra de navegación
            $('#nav-buttons a').each(function() {
                var linkUrl = $(this).attr('href');

                // Comprueba si la URL actual coincide con la URL del enlace
                if (currentUrl === linkUrl) {
                    // Agrega la clase 'active' a la clase 'icon-button' del enlace activo
                    $(this).find('.icon-button').addClass('active');
                }
            });
        });
    </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\MoneyControl\resources\views/Layouts/html.blade.php ENDPATH**/ ?>