<?php $__env->startSection('tittle-head'); ?>

    Profile
<?php $__env->stopSection(); ?>


<?php $__env->startSection('principal-container'); ?>
    <section id="profile">


        <section id="section-tittle-profile">
            <div class="back" onclick="back()"><i class='bx bx-chevron-left'></i></div>
            <div class="tittle text-center">
                <h2>Mi perfil</h2>
            </div>
            <p>x</p>
        </section>

        <article class="form-container">

            <form class="register-form" action="<?php echo e(route('login.login')); ?>" method="POST">

                <?php echo csrf_field(); ?>
                <article id="photo-profile">
                    <div class="cont-img">                                                
                        <img src="https://i.pinimg.com/originals/ef/e0/7d/efe07d9af104f338df556f48ba20ad62.png" alt="">
                    </div>
                </article>
                <input type="text" name="name" placeholder="UserName" required readonly value="<?php echo e($user->name); ?>">
                <input type="text" name="email" placeholder="Email" required readonly value="<?php echo e($user->email); ?>">            

                <a href="<?php echo e(route('profile.edit', $user)); ?>" class="btn-edit-profile">Actualizar datos</a>

                
            </form>

        </article>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.nav.nav-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Layouts.html', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MoneyControl\resources\views/Profile/user_profile.blade.php ENDPATH**/ ?>