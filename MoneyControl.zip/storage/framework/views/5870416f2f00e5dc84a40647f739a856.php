<?php $__env->startSection('principal-container'); ?>

<section id="byebye">

    <h1>A...a...adios! T_T</h1>

    <p>Que le vaya bien :)</p>

    <article class="cont-img">
        <img src="<?php echo e(asset('media/byebye.png')); ?>" alt="Adios bro">
    </article>

    <div class="btn">
        <a href="<?php echo e(route('welcome')); ?>">Bye</a>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.html', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MoneyControl\resources\views/Profile/byebye.blade.php ENDPATH**/ ?>