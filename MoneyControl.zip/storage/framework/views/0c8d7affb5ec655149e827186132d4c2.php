<?php $__env->startSection('tittle-head'); ?>
    Register
<?php $__env->stopSection(); ?>


<?php $__env->startSection('principal-container'); ?>
    <section id="register">


        <section id="section-tittle-login">
            <div class="back" onclick="back()"><i class='bx bx-chevron-left'></i></div>            
        </section>
        <div class="tittle">
            <h2>Regístrate</h2>
        </div>

        <article class="form-container">

            <form id="register-form"  action="<?php echo e(route('login.register')); ?>" method="POST">
                <?php echo csrf_field(); ?>              
                <input type="text" name="name" placeholder="UserName" required>
                <input type="text" name="email" placeholder="Correo" required>
                <input type="password" name="password" placeholder="Crea una contraseña" required>

                <button>Registrarme</button>

                <article class="redirect-lr">
                    <a href="<?php echo e(route('login.index_login')); ?>">Iniciar sesion</a>
                </article>

                
            </form>

        </article>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.html', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MoneyControl\resources\views/login-register/register.blade.php ENDPATH**/ ?>