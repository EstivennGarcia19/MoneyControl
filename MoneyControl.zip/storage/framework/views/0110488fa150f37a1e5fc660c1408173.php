<?php $__env->startSection('tittle-head'); ?>
    My Chest
<?php $__env->stopSection(); ?>


<?php $__env->startSection('principal-container'); ?>
    <section id="bg-container" style="background-color:<?php echo e($info_chest->color); ?> ">

        
        <section id="section-tittle-chest">
            <div class="tittle">
                <div class="back" onclick="back()"> <i class='bx bx-chevron-left'></i></div>

            </div>
            <div class="tittle">
                <div><span><?php echo e($info_chest->name); ?></span></div>
            </div>
            <div class="more-options" onclick="openOptions()">
                <i class='bx bx-dots-vertical-rounded'></i>
                <article class="options">
                    <form action="<?php echo e(route('chests.destroy', ['chest' => $info_chest->id])); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button href="#"><i class='bx bx-trash'></i><span>Borrar</span></button>
                    </form>
                    <a href="#"><i class='bx bx-brush-alt'></i><span>Editar</span></a>
                </article>
            </div>


        </section>

        
        <article id="avabilable-balance">
            <div class="amount">
                <span>Dinero disponible</span>
                <h2>$<?php echo e(formatCOP($info_chest->amount)); ?></h2>
            </div>


            <div class="options">
                <div class="add-money" data-bs-toggle="modal" data-bs-target="#addAmount">
                    <i class='bx bx-plus'></i>
                </div>
                <div class="remove-money" data-bs-toggle="modal" data-bs-target="#removeAmount">
                    <i class='bx bx-minus'></i>
                </div>

            </div>

        </article>

        <div id="history-chest">

            <article class="info-chest">
                <span>Actividad</span>
            </article>

            <section id="my-chests">
                <?php $__currentLoopData = $stalker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $joe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="history">
                        <article class="info">

                            <?php if($joe->action_per == 'Retirado'): ?>
                                <div class="icon cRed">
                                    <i class='bx bx-left-top-arrow-circle bx-rotate-90'></i>
                                </div>
                                <div class="date-state cRed">
                                    <h3><?php echo e($joe->action_per); ?></h3>
                                    <span><?php echo e(formatFullDate($joe->created_at)); ?></span>
                                </div>
                            <?php endif; ?>

                            <?php if($joe->action_per == 'Añadido'): ?>
                                <div class="icon">
                                    <i class='bx bx-left-top-arrow-circle bx-rotate-270'></i>
                                </div>
                                <div class="date-state">
                                    <h3><?php echo e($joe->action_per); ?></h3>
                                    <span><?php echo e(formatFullDate($joe->created_at)); ?></span>
                                </div>
                            <?php endif; ?>


                        </article>

                        <?php if($joe->action_per == 'Retirado'): ?>
                            <article class="amount">
                                <span>- $<?php echo e(formatCOP($joe->amount)); ?></span>
                            </article>
                        <?php endif; ?>
                        <?php if($joe->action_per == 'Añadido'): ?>
                            <article class="amount">
                                <span>$<?php echo e(formatCOP($joe->amount)); ?></span>
                            </article>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </section>
        </div>


        <!-- Modal -->
        <div class="modal fade" id="addAmount" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
            aria-labelledby="addAmountLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                <div class="modal-content">
                    <div class="modal-header d-flex justify-content-between">
                        <h1 class="modal-title fs-5" id="addAmount">Agregar dinero</h1>
                        <button type="button" class="btn text-light" data-bs-dismiss="modal"><i
                                class='bx bx-x'></i></button>
                    </div>
                    <div class="modal-body">
                        <div class="my-content-modal">

                            <form action="<?php echo e(route('chest.add_amount', $info_chest)); ?>" method="POST">
                                <?php echo method_field('PUT'); ?>
                                <?php echo csrf_field(); ?>
                                <article>
                                    <label for="input_add_amount"><img src="<?php echo e(asset('media/icon-addMoney3.png')); ?>"
                                            alt=""></label>
                                    <input type="hidden" placeholder="Name" name="name"
                                        value="<?php echo e($info_chest->name); ?>">
                                    <input type="text" placeholder="Amount" inputmode="numeric" class="price"
                                        id="input_add_amount" name="amount" value="">
                                    <input type="hidden" placeholder="Date" name="date"
                                        value="<?php echo e($info_chest->date); ?>">
                                </article>

                                <button><i class='bx bx-plus'></i></button>
                            </form>




                        </div>

                    </div>


                </div>
            </div>
        </div>

        <div class="modal fade" id="removeAmount" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
            aria-labelledby="removeAmountLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">

                <div class="modal-content">
                    <div class="modal-header d-flex justify-content-between">
                        <h1 class="modal-title fs-5" id="removeAmount">Retirar dinero</h1>
                        <button type="button" class="btn text-light" data-bs-dismiss="modal"><i
                                class='bx bx-x'></i></button>
                    </div>
                    <div class="modal-body">
                        <div class="my-content-modal">

                            <form action="<?php echo e(route('chest.remove_amount', $info_chest)); ?>" method="POST">
                                <?php echo method_field('put'); ?>
                                <?php echo csrf_field(); ?>
                                <article>
                                    <label for="amount"><img src="<?php echo e(asset('media/icon-removeMoney.png')); ?>"
                                            alt=""></label>
                                    <input type="hidden" placeholder="Name" name="name"
                                        value="<?php echo e($info_chest->name); ?>">
                                    <input type="text" placeholder="Cantidad" inputmode="numeric" class="price"
                                        name="amount" value="">
                                    <input type="hidden" placeholder="Date" name="date"
                                        value="<?php echo e($info_chest->date); ?>">
                                </article>
                                <button><i class='bx bx-minus'></i> </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('js/formatCOP.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('Layouts.nav.nav-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Layouts.html', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MoneyControl\resources\views/Chests/chest.blade.php ENDPATH**/ ?>