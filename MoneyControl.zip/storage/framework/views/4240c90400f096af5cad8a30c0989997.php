<?php echo $__env->yieldContent('nav-bar'); ?>

<nav id="nav-buttons">
    <ul>
        <li class="link-nav">
            <a href="<?php echo e(route('home.index')); ?>">
                <div class="icon-button">
                    <i class='bx bx-cricket-ball'></i>
                    <span>Home</span>
                </div>
            </a>
        </li>
        <li class="link-nav">
            <a href="<?php echo e(route('histoty.index')); ?>">
                <div class="icon-button">
                    <i class='bx bx-paper-plane'></i>
                    <span>Historial</span>
                </div>
            </a>
        </li>

        <?php echo $__env->yieldContent('btn-expenses-nav'); ?>
        <?php echo $__env->yieldContent('btn-chests-nav'); ?>

        <li class="link-nav">
            <a href="<?php echo e(route('chests.index')); ?>">
                <div class="icon-button">
                    <i class='bx bx-credit-card'></i>
                    <span>Cofres</span>
                </div>
            </a>
        </li>
        <li class="link-nav">
            
            <a href="<?php echo e(route('profile.show', ['id'=>Auth::user()->id])); ?>">
                <div class="icon-button">
                    <i class='bx bx-user'></i>
                    <span>Perfil</span>
                </div>
            </a>
        </li>
    </ul>
</nav>
<?php /**PATH C:\xampp\htdocs\MoneyControl\resources\views/Layouts/nav/nav-bar.blade.php ENDPATH**/ ?>