@section('btn-chests-nav')

<li>
    <button type="button" data-bs-toggle="modal" data-bs-target="#staticBackdrop"><i class='bx bx-plus'></i></button>    
</li>

@endsection