@section('btn-expenses-nav')

<li>
    <button form="this-form" ><i class='bx bx-plus'></i></button>
</li>



@endsection