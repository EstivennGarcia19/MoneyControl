function back() {

    window.history.back();

}


function pene() {


    alert("hola")
    // const pene = document.querySelector('.more-options .more-options');

    // pene.classList.add('active');
    
}